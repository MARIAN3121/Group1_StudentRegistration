package com.example.students_registration;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import com.example.students_registration.databinding.ActivityHomeBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Home_activity extends AppCompatActivity {
    ActivityHomeBinding binding;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityHomeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        binding.btsearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String studentname = binding.txtfname.getText().toString();
                if (!studentname.isEmpty()) {
                    readData(studentname);
                }
                else{
                    Toast.makeText(Home_activity.this,"Enter First name",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private void readData(String student) {
        reference = FirebaseDatabase.getInstance().getReference("Students");
        reference.child(student).get().addOnCompleteListener(new OnCompleteListener<DataSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DataSnapshot> task) {
                if (task.isSuccessful()) {
                    if (task.getResult().exists()){
                        Toast.makeText(Home_activity.this,"Student found",Toast.LENGTH_SHORT).show();
                        DataSnapshot snop = task.getResult();
                        String firstname = String.valueOf(snop.child("fname").getValue());
                        String lastname = String.valueOf(snop.child("lname").getValue());
                        String course = String.valueOf(snop.child("course").getValue());
                        String year = String.valueOf(snop.child("year").getValue());
                        binding.txtfname.setText(firstname);
                        binding.txtlname.setText(lastname);
                        binding.txtcourse.setText(course);
                        binding.txtyr.setText(year);
                    }
                }
                else{
                    Toast.makeText(Home_activity.this,"Failed to read",Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}
