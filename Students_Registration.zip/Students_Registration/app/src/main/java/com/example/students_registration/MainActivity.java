package com.example.students_registration;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.students_registration.databinding.ActivityMainBinding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    ActivityMainBinding binding;String fname, lname, age,year,course,address;
    FirebaseDatabase db;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.Btreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fname = binding.textfname.getText().toString();
                lname = binding.textlname.getText().toString();
                age = binding.textage.getText().toString();
                year = binding.textyear.getText().toString();
                course = binding.textcourse.getText().toString();
                address = binding.textaddress.getText().toString();

                if (!fname.isEmpty() && !lname.isEmpty() && !age.isEmpty() && !year.isEmpty() && !course.isEmpty() && !address.isEmpty()) {
                    Students stud = new
                            Students(fname, lname, age, year, course, address);
                    db = FirebaseDatabase.getInstance();
                    reference = db.getReference("Students");

                    reference.child(fname).setValue(stud).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            binding.textfname.setText("");
                            binding.textlname.setText("");
                            binding.textage.setText("");
                            binding.textyear.setText("");
                            binding.textcourse.setText("");
                            binding.textaddress.setText("");

                            Toast.makeText(MainActivity.this, "Updated", Toast.LENGTH_SHORT).show();
                        }
                    });

                }
            }
        });


    }
}